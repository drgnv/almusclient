<?php
error_reporting(E_ERROR);
session_start();
if(!isset($_SESSION['user_info'])){
    header("Location: ../index.php");
}
include '../libs/Smarty.class.php';
include_once '../model/Basic.php';
$Smarty = new Smarty();
$Smarty->template_dir='../view/';
$Smarty->compile_dir='../template_c/';


$Basic = new Basic();
if(isset($_GET['street']) && isset($_GET['number']) && isset($_GET['post_code'])){
    
$data['street'] = $_GET['street'].'-'.$_GET['number'].'-'.$_GET['post_code'];
$data['user_id'] = $_SESSION['user_info'][0]['user_id'];
if($_GET['addfav'] == 'on' || $_GET['addfav'] == 1){
    $data2['street'] = $_GET['street'];
    $data2['number'] = $_GET['number'];
    $data2['post_code'] = $_GET['post_code'];
    $data2['user_id'] = $_SESSION['user_info'][0]['user_id'];
    $Basic->setNewFavPlace($data2);
}
$order_id = $Basic->setNewOrder($data);
header('Location: view_order.php?order_id='.$order_id[0]['max(order_id)']);


}

$Smarty->assign('user_info', $_SESSION['user_info']);
$Smarty->display('get_taxi.tpl');