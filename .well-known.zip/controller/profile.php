<?php
error_reporting(E_ERROR);
session_start();
if(!isset($_SESSION['user_info'])){
    header("Location: ../index.php");
}
include '../libs/Smarty.class.php';
include_once '../model/Basic.php';
$Smarty = new Smarty();
$Smarty->template_dir='../view/';
$Smarty->compile_dir='../template_c/';


$Basic = new Basic();

if(isset($_POST['save'])){
$data['names'] = $_POST['names'];
$data['mail'] = $_POST['mail'];
$data['phone'] = $_POST['phone'];
$data['user_id'] = $_SESSION['user_info'][0]['user_id'];
$Basic->setUserById($data);
header('Location: ./profile.php?ok=true');
}
$user_info = $Basic->getUserById($_SESSION['user_info'][0]['user_id']);
if(isset($_GET['ok'])){
    $Smarty->assign('ok', $_GET['ok']);
}
$Smarty->assign('user_info2', $user_info);
$Smarty->assign('user_info', $_SESSION['user_info']);
$Smarty->display('profile.tpl');
