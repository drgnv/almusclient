<?php
error_reporting(E_ERROR);
session_start();
if(!isset($_SESSION['user_info'])){
    header("Location: ../index.php");
}
include '../libs/Smarty.class.php';
include_once '../model/Basic.php';
$Smarty = new Smarty();
$Smarty->template_dir='../view/';
$Smarty->compile_dir='../template_c/';

echo $_COOKIE['usermail'];
$Basic = new Basic();
$favorite_places = $Basic->getFavPlacesByUserId($_SESSION['user_info'][0]['user_id']);
if(isset($_GET['finished_order'])){

    $Smarty->assign('msg', 'Вашето пътуване приключи успешно');
}

$active_orders = $Basic->getActiveOrdersByUserId($_SESSION['user_info'][0]['user_id']);

if(is_array($active_orders)){
    foreach($active_orders as $key => $order){
        $active_orders[$key]['start_destiantion'] = explode('-', $order['start_destiantion']);
        $active_orders[$key]['end_destination'] = explode('-', $order['end_destination']);
         $active_orders[$key]['time'] = explode('-', $order['time']);
         $active_orders[$key]['date'] = explode('-', $order['date']);
    }
   // print_r($active_orders);
   $Smarty->assign('active_orders', $active_orders);
}


$Smarty->assign('fav_pl', $favorite_places);
$Smarty->assign('user_info', $_SESSION['user_info']);
$Smarty->display('home.tpl');
