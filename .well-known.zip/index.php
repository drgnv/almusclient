<?php
include './libs/Smarty.class.php';
include_once './model/Basic.php';
include_once 'config.php';
$redirectURL = 'https://almus.semicolondi.com/fb-callback.php';
$permissions = ['email'];
$loginURL =  $helper->getLoginUrl($redirectURL, $permissions);
//echo $loginURL;
$Basic = new Basic();
if(isset($_COOKIE['emailalmus']) && isset($_COOKIE['passwordalmus'])){
    $Basic->logIn($_COOKIE['emailalmus'], $_COOKIE['passwordalmus']);
}

$redirectURL = "http://almus.semicolondi.com/fb-callback.php";
	$permissions = ['email'];
	$loginURL = $helper->getLoginUrl($redirectURL, $permissions);


$Smarty = new Smarty();
$Smarty->template_dir='./view/';
$Smarty->compile_dir='./template_c/';

$Smarty->assign('lurl', $loginURL);
$Basic = new Basic();

error_reporting(E_ERROR);
session_start();

if(isset($_SESSION['userData']) || isset($_COOKIE['emailalmus'])){
    if(strlen($_SESSION['userData']['email'])>4){
         $user_info = $Basic->userExist($_SESSION['userData']['email']);
    
    }
    
     if(strlen($_COOKIE['emailalmus'])>4){
         $user_info = $Basic->userExist($_COOKIE['emailalmus']);
    
    }
   
    if(is_array($user_info)){
        $_SESSION['user_info'] = $user_info;
    }else{
        $data['names'] = $_SESSION['userData']['first_name'].' '.$_SESSION['userData']['last_name'];
        $data['mail'] = $_SESSION['userData']['email'];
        $data['phone'] = 0;
        $data['password'];
        $Basic->register($data);
         $user_info = $Basic->userExist($_SESSION['userData']['email']);
         $_SESSION['user_info'] = $user_info;
    }
}

if(isset($_SESSION['user_info'])){
    header("Location: ./controller/home.php");
}




if(isset($_GET['error'])){
    $Smarty->assign('error', $_GET['error']);
}

if(isset($_POST['password'])){

    $username = filter_input(INPUT_POST, 'username');
    $password = filter_input(INPUT_POST, 'password');
    $rememberme = filter_input(INPUT_POST, 'remember');

    if(strlen($username)<4 || strlen($password)<7){
         header("Location: ./index.php?error=Грешно име или парола!");
    }else{
        if($Basic->logIn($username, $password, $rememberme) == true){
             if(isset($_POST['remember'])){
             $rem = filter_input(INPUT_POST, 'remember');
      
             setcookie('emailalmud', $username, time()+60*60*365);
              setcookie('passwordalmus', $password, time()+60*60*365);
       
        }
       // $_SESSION['login'] = true;
        header("Location: ./controller/home.php");
    }else{
        
        session_destroy();
         header("Location: ./index.php?error=Грешно име или парола!");
    }

    }
    



}

//print_r($_COOKIE);
//print_r($_SESSION['userData']);
//$Smarty->assign('doctors', $doctors);
$Smarty->display('index.tpl');
