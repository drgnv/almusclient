<?php
error_reporting(E_ERROR);
session_start();
if(isset($_SESSION['user_info'])){
    header("Location: ./controller/home.php");
}
include './libs/Smarty.class.php';
include_once './model/Basic.php';



$Smarty = new Smarty();
$Smarty->template_dir='./view/';
$Smarty->compile_dir='./template_c/';

$Basic = new Basic();
if(isset($_GET['error'])){
    $Smarty->assign('error', $_GET['error']);
}

    if(isset($_POST['register'])){

        if($Basic->checkIfMailExist($_POST['mail'])){
            header('Location: ./register.php?error=Този мейл вече съществува. Опитайте отново');
        }else{
            if(strlen($_POST['password'])<8){
                header('Location: ./register.php?error=Паролата трябва да бъде дълга поне 8 символа. Опитайте отново');
            }else{
                if(strlen($_POST['phone'])<10 || strlen($_POST['phone'])>10){
                    header('Location: ./register.php?error=Моля въведете валиден телефонен номер');
                }else{
                    if(strlen($_POST['names'])<4){
                        header('Location: ./register.php?error=Въведете валидно име от поне 4 символа');
                    }else{
                     $data['names'] = $_POST['names'];
                     $data['mail'] = $_POST['mail'];
                     $data['phone'] = $_POST['phone'];
                     $data['password'] = $_POST['password'];
                     $Basic->register($data);
                    }
                    
                }
                
            }
        }

    }





//$Smarty->assign('doctors', $doctors);
$Smarty->display('index.tpl');
