<?php

include_once 'Host.php';
class Basic extends Host{

    public function logIn($username, $password, $rememberme){
        
        $sql = "SELECT * FROM users WHERE user_mail = '".mysqli_real_escape_string($this->connect(),$username)."' && users.user_status = 1";
        $_SESSION['user_info'] = $this->sqliexecute($sql);
        $password_verify = password_verify($password, $_SESSION['user_info'][0]['user_password']);
        
        if(trim($_SESSION['user_info'][0]['user_mail']) == trim($username) && $password_verify == 1){
          
                setcookie( "user_ifo", $_SESSION['user_info'], strtotime( '+30 days' ) );
           
            return true;
            
        }else{
            
            return false;
            
        }

    }
    
    public function getUserByMail($mail){
        $sql = "SELECT * FROM users WHERE users.user_mail = '".$mail."'";
        return $this->sqliexecute($sql);
    }

    public function checkPassword($user_id, $password){
        $sql = "SELECT * FROM users WHERE user_id = '".mysqli_real_escape_string($this->connect(),$user_id)."' && users.user_status = 1";
        $_SESSION['user_info2'] = $this->sqliexecute($sql);
        $password_verify = password_verify($password, $_SESSION['user_info2'][0]['user_password']);
        if($password_verify == 1){

            return true;

        }else{

            return false;

        }

    }

    public function changePassword($user_id, $password){
        $pass = password_hash($password, PASSWORD_DEFAULT);
        $sql = "UPDATE `users` SET `user_password` = '".mysqli_real_escape_string($this->connect(), $pass)."' WHERE `users`.`user_id` = ".mysqli_real_escape_string($this->connect(), $user_id);
       // echo $sql;
        $this->sqliexecute($sql);
    }

    public function getFavPlacesByUserId($user_id){
        $sql = "SELECT * FROM favorite_places WHERE user_id = '".mysqli_real_escape_string($this->connect(), $user_id)."'";
        return $this->sqliexecute($sql);
    }

    public function setNewOrder($data){
        $date = date('Y-m-d'); //G-i-s
        $time = date('G-i-s');
        $sql = "INSERT INTO `orders` (`user_id`, `start_destiantion`, `end_destination`, `driver_Id`, `status`, `date`, `time`, `order_id`, `ordre_note`) 
        VALUES ('".mysqli_real_escape_string($this->connect(), $data['user_id'])."', '".mysqli_real_escape_string($this->connect(), $data['street'])."', '', 0, '1', '".mysqli_real_escape_string($this->connect(), $date)."', '".mysqli_real_escape_string($this->connect(), $time)."', NULL, '')";
        $this->sqliexecute($sql);
        $sql = "SELECT max(order_id) FROM orders WHERE user_id = ".mysqli_real_escape_string($this->connect(), $data['user_id']);
        return $this->sqliexecute($sql);
    }

    public function getOrderById($id){
        $sql = "SELECT * FROM orders WHERE order_id = ".mysqli_real_escape_string($this->connect(), $id);
        return $this->sqliexecute($sql);
    }

    public function checkOrderStatus($id){
        $sql = "SELECT * FROM orders WHERE order_id = ".mysqli_real_escape_string($this->connect(), $id);
        $order = $this->sqliexecute($sql);
       // echo $order[0]['driver_Id'];
        if($order[0]['driver_id'] == '0'){
            $data['driver_info'] = false;
        }else{
            $data['driver_info'] = $this->getDriverById($order[0]['driver_Id']);
        }

        if($order[0]['status'] == 1){
            $data['status'] = 1;
        }
        if($order[0]['status'] == 2){
            $data['status'] = 2;
        }
        if($order[0]['status'] == 3){
            $data['status'] = 3;
        }
        if($order[0]['status'] == 4){
            $data['status'] = 4;
        }

        return $data;
    }


    public function getDriverById($id){
        $sql = "SELECT * FROM drivers WHERE driver_Id = ".mysqli_real_escape_string($this->connect(), $id);
        return $this->sqliexecute($sql);
    }

    public function getUserById($id){
        $sql = "SELECT * FROM users WHERE user_id = ".mysqli_real_escape_string($this->connect(), $id);
        return $this->sqliexecute($sql);
    }

    public function setUserById($data){
        $sql = "UPDATE `users` SET `user_names` = '".mysqli_real_escape_string($this->connect(), $data['names'])."', `user_mail` = '".mysqli_real_escape_string($this->connect(), $data['mail'])."', `user_phone` = '".mysqli_real_escape_string($this->connect(), $data['phone'])."' WHERE `users`.`user_id` = ".mysqli_real_escape_string($this->connect(), $data['user_id']);
        $this->sqliexecute($sql);
    }

    public function deleteFavPlace($id){
        $sql = "DELETE FROM favorite_places WHERE `favorite_places`.`fav_place_id` = ".mysqli_real_escape_string($this->connect(), $id);
        $this->sqliexecute($sql);
       // echo $sql;
    }

    public function setNewFavPlace($data){
        $sql = "INSERT INTO `favorite_places` (`street`, `street_number`, `post_code`, `user_id`, `fav_place_id`) 
VALUES ('".$data['street']."', '".mysqli_real_escape_string($this->connect(), $data['number'])."', '".mysqli_real_escape_string($this->connect(), $data['post_code'])."', '".mysqli_real_escape_string($this->connect(), $data['user_id'])."', NULL)";
        $this->sqliexecute($sql);
    }

    public function refuseOrder($order_id){
        $sql = "UPDATE orders SET orders.status = 4 WHERE order_id = ".mysqli_real_escape_string($this->connect(), $order_id);
        $this->sqliexecute($sql);
       // echo $sql;
    }

    public function register($data){
        $pass = password_hash($data['password'], PASSWORD_DEFAULT);
        $sql = "INSERT INTO `users` (`user_names`, `user_password`, `user_id`, `user_status`, `user_mail`, `user_phone`) 
                        VALUES ('".$data['names']."', '".mysqli_real_escape_string($this->connect(), $pass)."', NULL, '1', '".mysqli_real_escape_string($this->connect(), $data['mail'])."', '".mysqli_real_escape_string($this->connect(), $data['phone'])."');";
        $this->sqliexecute($sql);
    }

    public function checkIfMailExist($mail){
        $sql = "SELECT * FROM users WHERE user_mail = '".mysqli_real_escape_string($this->connect(), $mail)."'";
        $result = $this->sqliexecute($sql);
        if(is_string($result[0]['user_mail'])){
            return 1;
        }else{
            return 0;
        }
    }

    public function getOrdersByUserId($id){
        $sql = "SELECT * FROM orders WHERE user_id = ".mysqli_real_escape_string($this->connect(), $id)." ORDER BY order_id DESC";
        return $this->sqliexecute($sql);
    }

    public function updateDriverRating($new_rating, $driver_rating_count, $driver_id, $order_id){
        $sql = "UPDATE drivers SET driver_rating = ".mysqli_real_escape_string($this->connect(), $new_rating).", driver_rating_count = ".mysqli_real_escape_string($this->connect(), $driver_rating_count)." WHERE driver_id = ".mysqli_real_escape_string($this->connect(), $driver_id);
       $this->sqliexecute($sql);

       //UPDATE `orders` SET `status` = '3' WHERE `orders`.`order_id` = 100;
       $sql = "UPDATE `orders` SET `status` = '3' WHERE `orders`.`order_id` = ".mysqli_real_escape_string($this->connect(), $order_id);
        $this->sqliexecute($sql);
     // echo $sql;
    }

    public function addEndPoint($data){
        $sql = "UPDATE orders SET end_destination = '".mysqli_real_escape_string($this->connect(), $data['street'])."-".mysqli_real_escape_string($this->connect(), $data['num'])."-".mysqli_real_escape_string($this->connect(), $data['post_code'])."' WHERE order_id = ".mysqli_real_escape_string($this->connect(), $data['order_id']);
       // echo $sql;
        $this->sqliexecute($sql);
    }
    
    public function getActiveOrdersByUserId($user_id){
        $sql = "SELECT * FROM orders WHERE `user_id` = ".mysqli_real_escape_string($this->connect(), $user_id)." AND status != 3 AND status != 4";
        return $this->sqliexecute($sql);
    }
    
    
    public function userExist($mail){
        $sql = "SELECT * FROM users WHERE user_mail = '".$mail."'";
        $user = $this->sqliexecute($sql);
        if(is_array($user)){
            return $user;
        }else{
            return false;
        }
    }
    
    public function getDriversLinks(){
        $sql = "SELECT * FROM drivers WHERE 1=1";
        return $this->sqliexecute($sql);
    }

}
