<?php
/* Smarty version 3.1.32, created on 2020-06-11 16:39:24
  from '/home/vsyakadu/almus.semicolondi.com/view/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5ee2340cbaefb1_80284933',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6c6e66afb40412491ab1c236e66db85aedda1526' => 
    array (
      0 => '/home/vsyakadu/almus.semicolondi.com/view/footer.tpl',
      1 => 1588779532,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ee2340cbaefb1_80284933 (Smarty_Internal_Template $_smarty_tpl) {
?>
</body>
</html>
<!-- partial -->
<?php echo '<script'; ?>
  src="../js/home.js"><?php echo '</script'; ?>
>

</body>
</html>
<?php }
}
