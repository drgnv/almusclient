<?php
/* Smarty version 3.1.32, created on 2020-07-10 17:21:09
  from '/home/vsyakadu/almus.semicolondi.com/view/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5f08795558e509_98820306',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9f0096ba43c26ca6d6892eb782adcec3d430fffb' => 
    array (
      0 => '/home/vsyakadu/almus.semicolondi.com/view/index.tpl',
      1 => 1594390444,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f08795558e509_98820306 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Almus Taxi</title>
  <link rel="stylesheet" href="../lstyle.css">

</head>
<body style="background-color:#171717;">
<!-- partial:index.partial.html -->
<!-- Designed by Jaysen Henderson. Developed by me for fun. Source: https://dribbble.com/shots/3686055-hello-login-Ui -->

<div class="wrapper11" style="border:none;background-color:#171717;">
  
  <!--  Header  -->
  <header class="section header" style="border:none;">
    
    <div class="header__text1" style="padding:0;margin:0;border:none;">
      <img src="./images/luber.png" width="180" height="140">
 <?php if (isset($_smarty_tpl->tpl_vars['error']->value)) {?>
 <p style="background-color: red;color:white; padding:1px;"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</p>
 <?php }?>
    </div>
  </header>

    <!--  Sign Up  -->
    <section class="section sign-up" style="padding:0;margin:0;">
      <form action="./register.php" method="POST">
       <input type="text" name="names" placeholder="Имена" style="padding-bottom: 0px; height:55px; font-size:22px;background-color:#171717;color:white;">
            <input type="email" name="mail" placeholder="Mail" style="padding-bottom: 0px; height:55px; font-size:22px;background-color:#171717;color:white;">
            <input type="text" name="phone" placeholder="Телефон" style="padding-bottom: 0px; height:55px; font-size:22px;background-color:#171717;color:white;">
            <input type="text" name="password" placeholder="Парола" style="padding-bottom: 0px; height:55px; font-size:22px;background-color:#171717;color:white;">
            <input type="hidden" name="register" value="Регистрирай се" >
        
        <button style="padding-bottom: 0px; height:55px; font-size:22px;color:white">Регистрирай се</button>
        <p class="opposite-btn2" style="font-size:19px;color:white">Вече имаш профил?</p>
        <hr>
       <center></center>  <a href="https://almus.semicolondi.com/rights.php" style="text-decoration: none; color:white; font-size:19px">С натискането на бутон "Регистрирай се" Вие приемате  общите правила</a>
       </center>
      </form>
    </section>
    
    <!--  Sign In  -->
    <section class="section sign-in" style="padding:0;margin:0;border:none;"><center>
      <br>  <a href="<?php echo $_smarty_tpl->tpl_vars['lurl']->value;?>
"><img src="../images/fl.png" style="width: 90%"></a><br><br><br></center>
      <form action="./index.php" method="post">
           <input class="info1" id="username" type="text" name="username" placeholder="Имейл" style="padding-bottom: 0px; height:55px; font-size:22px;background-color:#171717;">
        <input class="info1" id="password" type="password" name="password" placeholder="Парола" style="padding-bottom: 0px; height:55px;font-size:22px;background-color:#171717;">
    <br>  <input type="checkbox" name="remember" value="1" style="width:20px;height:20px"><b style="color:white;">Запомни ме</b><center>
    <br>   <button style="background-color: #dea527;color: white;height:55px; font-size:22px;width:80%;border-radius: 10px;" id="login" type="submit" >Вход</button>
       </center><br> <p class="opposite-btn1" style="font-size:22px;color:white;">Нямаш профил? Регистрирай се</p>
       <center><br> <a href="https://almus.semicolondi.com/rights.php" style="text-decoration: none; color:white; font-size:20px; vertical-align: text-bottom;bottom:5px">Общи правила</a>
     </center> </form>
    </section>
</div>
<!-- partial -->
  <?php echo '<script'; ?>
  src="../lscript.js"><?php echo '</script'; ?>
>

</body>
</html>
<?php }
}
