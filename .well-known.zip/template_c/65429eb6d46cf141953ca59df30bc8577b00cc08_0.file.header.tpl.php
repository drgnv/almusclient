<?php
/* Smarty version 3.1.32, created on 2020-06-04 12:20:20
  from '/var/www/html/luber/view/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5ed8bcd4e360e6_64061207',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '65429eb6d46cf141953ca59df30bc8577b00cc08' => 
    array (
      0 => '/var/www/html/luber/view/header.tpl',
      1 => 1591262376,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ed8bcd4e360e6_64061207 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en" >
<head>
    <meta charset="UTF-8">
    <title>Luber</title>
    <link rel="stylesheet" href="../css/home.css">

</head>
<body>
<!-- partial:index.partial.html -->
<html>
<head>

    <meta charset="utf-8"><title>Luber</title>
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
    <link href="https://code.ionicframework.com/1.0.0-rc.5/css/ionic.min.css" rel="stylesheet">
    <?php echo '<script'; ?>
 src="https://code.ionicframework.com/1.0.0-rc.5/js/ionic.bundle.js"><?php echo '</script'; ?>
>

</head>
<body ng-app="starter">
<?php }
}
