<?php
/* Smarty version 3.1.32, created on 2020-05-06 18:39:13
  from '/var/www/html/luber/view/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5eb2da2107d897_20386121',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3b0df0a4434ca52911f5b98f982c4e4b5c989848' => 
    array (
      0 => '/var/www/html/luber/view/footer.tpl',
      1 => 1588779533,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5eb2da2107d897_20386121 (Smarty_Internal_Template $_smarty_tpl) {
?>
</body>
</html>
<!-- partial -->
<?php echo '<script'; ?>
  src="../js/home.js"><?php echo '</script'; ?>
>

</body>
</html>
<?php }
}
