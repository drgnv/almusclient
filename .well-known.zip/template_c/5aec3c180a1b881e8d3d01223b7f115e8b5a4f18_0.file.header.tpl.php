<?php
/* Smarty version 3.1.32, created on 2020-06-11 16:39:24
  from '/home/vsyakadu/almus.semicolondi.com/view/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5ee2340cbaa765_68037446',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5aec3c180a1b881e8d3d01223b7f115e8b5a4f18' => 
    array (
      0 => '/home/vsyakadu/almus.semicolondi.com/view/header.tpl',
      1 => 1591262376,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ee2340cbaa765_68037446 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en" >
<head>
    <meta charset="UTF-8">
    <title>Luber</title>
    <link rel="stylesheet" href="../css/home.css">

</head>
<body>
<!-- partial:index.partial.html -->
<html>
<head>

    <meta charset="utf-8"><title>Luber</title>
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
    <link href="https://code.ionicframework.com/1.0.0-rc.5/css/ionic.min.css" rel="stylesheet">
    <?php echo '<script'; ?>
 src="https://code.ionicframework.com/1.0.0-rc.5/js/ionic.bundle.js"><?php echo '</script'; ?>
>

</head>
<body ng-app="starter">
<?php }
}
