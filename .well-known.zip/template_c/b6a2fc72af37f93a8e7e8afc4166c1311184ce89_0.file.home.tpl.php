<?php
/* Smarty version 3.1.32, created on 2020-07-05 13:56:57
  from '/home/vsyakadu/almus.semicolondi.com/view/home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5f01b1f9f15165_93543472',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b6a2fc72af37f93a8e7e8afc4166c1311184ce89' => 
    array (
      0 => '/home/vsyakadu/almus.semicolondi.com/view/home.tpl',
      1 => 1593946616,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:menu.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5f01b1f9f15165_93543472 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<head>
    <style>
    
    
    
    
    
    
        .collapsible {
            background-color: #777;
            color: white;
            cursor: pointer;
            padding: 18px;
            width: 100%;
            border: none;
            text-align: left;
            outline: none;
            font-size: 15px;
        }

        .active, .collapsible:hover {
            background-color: #555;
        }

        .content {
            padding: 0 18px;
            display: none;
            overflow: hidden;
            background-color: #f1f1f1;
        }
        
        input:focus {
  background-color: yellow;
}
    </style>
    <style>
        table {
            border-collapse: collapse;
        }

         td {
            width:150px;
            text-align:center;
            border:0px ;
            padding:5px

        }
        .geeks {
            border-right:hidden;
        }
        .gfg {
            border-collapse:separate;
            border-spacing:0 10px;
        }
        h1 {
            color:green;
        }
    </style>
    <ion-nav-view></ion-nav-view>

<?php echo '<script'; ?>
 id="menu.html" type="text/ng-template">
    <ion-side-menus enable-menu-with-back-views="false">
        <ion-side-menu-content >
            <ion-nav-bar class="bar-stable">
                <ion-nav-back-button>
                </ion-nav-back-button>

                <ion-nav-buttons side="left">

                    <button class="button button-icon" menu-toggle="left">
                        <span class="menuButton" ng-class="$ionicSideMenuDelegate.isOpen() ? 'menu-arrowButton' : 'arrow-menuButton'"  ></span>
                    </button>

                </ion-nav-buttons>
            </ion-nav-bar>
            <ion-nav-view name="menuContent"></ion-nav-view>
        </ion-side-menu-content>

        <ion-side-menu side="left">

            <?php $_smarty_tpl->_subTemplateRender("file:menu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 id="feed.html" type="text/ng-template">
    <!-- Feed Screen - Refer to feed.scss -->
    <ion-view view-title="Luber" hide-nav-bar="true" class="rubyonic-pane feed-screen">

        <div class="bar bar-ruby-header bar-transparent">
            <button class="button ruby-button-clear icon ion-navicon brand-base-text-color" menu-toggle="left">
                <span class="new-notification-bubble"></span>
            </button>
            <h1 class="title brand-base-text-color"><img src="../images/luber.png" width="90" height="40"></h1>
            <button class="button ruby-button-clear icon ion-android-notifications brand-base-text-color" menu-toggle="right"></button>
        </div>
        <!-- End Custom navbar -->
        <ion-content class="has-header">

            <div class="padding feed ruby">
            
            
            <?php if (strlen($_smarty_tpl->tpl_vars['user_info']->value[0]['user_phone']) < 10) {?><center>
            <div style="background-color: black; color:#dea527" onclick="window.location='./profile.php'">
            Виждаме, че не стe посочили телефонен номер. Можете да го направите от ТУК.
            </div></center>
            <?php }?>
            
                <?php if (isset($_smarty_tpl->tpl_vars['msg']->value)) {?>
                    <p style="background-color: green;padding: 5px; color:white; text-align: center"><?php echo $_smarty_tpl->tpl_vars['msg']->value;?>
</p>
                <?php }?>
                    <table style="width: 100%;" class = "gfg" >
                   
                    <?php if (isset($_smarty_tpl->tpl_vars['active_orders']->value)) {?>
                    
                     <p style="color:#dea527; background-color: black;text-align:center;opacity:0.8">Имате активни поръчки</p>
                     
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['active_orders']->value, 'active_order', false, 'k');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['k']->value => $_smarty_tpl->tpl_vars['active_order']->value) {
?>
                        <div onclick="window.location='view_order.php?order_id=<?php echo $_smarty_tpl->tpl_vars['active_order']->value['order_id'];?>
';"
                        <?php if ($_smarty_tpl->tpl_vars['active_order']->value['status'] == 1) {?>
                        style = "background-color: #54c769; color: white; padding 3px; margin: 4px;cursor: pointer;";
                        <?php }?>
                        <?php if ($_smarty_tpl->tpl_vars['active_order']->value['status'] == 2) {?>
                        style = "background-color: #4993c4; color: white; padding 3px; margin: 4px;cursor: pointer;";
                        <?php }?>
                        >
                        
                        <div style="margin:4px; background-color:black;opacity: 0.78; padding: 5px">
                        
                      <p><?php echo $_smarty_tpl->tpl_vars['active_order']->value['time'][0];?>
:<?php echo $_smarty_tpl->tpl_vars['active_order']->value['time'][1];?>
:<?php echo $_smarty_tpl->tpl_vars['active_order']->value['time'][2];?>
ч. | 
                      <?php echo $_smarty_tpl->tpl_vars['active_order']->value['date'][2];?>
.<?php echo $_smarty_tpl->tpl_vars['active_order']->value['date'][1];?>
.<?php echo $_smarty_tpl->tpl_vars['active_order']->value['date'][0];?>

                      <br>
                      От: ул.<?php echo $_smarty_tpl->tpl_vars['active_order']->value['start_destiantion'][0];?>
 №<?php echo $_smarty_tpl->tpl_vars['active_order']->value['start_destiantion'][1];?>
 ПК:<?php echo $_smarty_tpl->tpl_vars['active_order']->value['start_destiantion'][2];?>
<hr>
                       До: ул.<?php echo $_smarty_tpl->tpl_vars['active_order']->value['end_destination'][0];?>
 №<?php echo $_smarty_tpl->tpl_vars['active_order']->value['end_destination'][1];?>
 ПК:<?php echo $_smarty_tpl->tpl_vars['active_order']->value['end_destination'][2];?>

                       </p>
                       </div>
                       
                        </div>
                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    
                    <?php }?>
                    
                    
                        <p style="text-align: center; background-color: #a2a2a2; padding: 3px; margin: 3px; width: 100%;-webkit-box-shadow: 3px 3px 18px -5px rgba(0,0,0,0.75);
-moz-box-shadow: 3px 3px 18px -5px rgba(0,0,0,0.75);
box-shadow: 3px 3px 18px -5px rgba(0,0,0,0.75); background: radial-gradient(#387989, #1b6da6);
  background-repeat: no-repeat;color:#ebff36;font-weight: bold;"

                        >Избери от любимите си адреси: </p>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['fav_pl']->value, 'place');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['place']->value) {
?>
                        <tr style=" border-spacing:0 15px;">
                            <td style="text-align: center; padding: 5px; background-color: #1b1c13; opacity: 0.9;color: yellow;-webkit-box-shadow: 3px 3px 18px -5px rgba(0,0,0,0.75);
-moz-box-shadow: 3px 3px 18px -5px rgba(0,0,0,0.75);
box-shadow: 3px 3px 18px -5px rgba(0,0,0,0.75);background: radial-gradient(#387989, #11466b);
  background-repeat: no-repeat;"">★
                                <a href="./get_taxi.php?street=<?php echo $_smarty_tpl->tpl_vars['place']->value['street'];?>
&number=<?php echo $_smarty_tpl->tpl_vars['place']->value['street_number'];?>
&post_code=<?php echo $_smarty_tpl->tpl_vars['place']->value['post_code'];?>
"
                                style="color:#ebff36; text-decoration: none"
                                   <a href="return confirm('Сигурни ли сте, че искате да повикате такси на ул.<?php echo $_smarty_tpl->tpl_vars['place']->value['street'];?>
 №<?php echo $_smarty_tpl->tpl_vars['place']->value['street_number'];?>
 ПК:<?php echo $_smarty_tpl->tpl_vars['place']->value['post_code'];?>
?')"  >
                                ул.<?php echo $_smarty_tpl->tpl_vars['place']->value['street'];?>
 №<?php echo $_smarty_tpl->tpl_vars['place']->value['street_number'];?>
 ПК:<?php echo $_smarty_tpl->tpl_vars['place']->value['post_code'];?>

                                </a>
                            </td>
                        </tr>
                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </table>





                <div style="text-align: center; background-color: #1b1c13; padding: 3px; margin: 3px; width: 100%; opacity: 0.9; color: white;-webkit-box-shadow: 3px 3px 18px -5px rgba(0,0,0,0.75);
-moz-box-shadow: 3px 3px 18px -5px rgba(0,0,0,0.75);
box-shadow: 3px 3px 18px -5px rgba(0,0,0,0.75);background: radial-gradient(#387989, #6dd5ed);
  background-repeat: no-repeat;">
                    <b>или въведи друг адрес</b>
                    <br><br><center>
                        <form action="./get_taxi.php" method="get">
                    <input type="text" name="street" placeholder="Улица" style="width: 100%" required><br>
                    <input type="number" name="number" placeholder="№" style="width: 100%" required><br>
                    <input type="number" name="post_code" placeholder="ПК" size="1" style="width: 100%"><br>
                    <input type="checkbox" name="addfav" id="addfav"><lable for="addfav">Добави към любими</lable>
                            <input type="submit" name="call_taxi" value="ПОВИКАЙ ТАКСИ" style="width: 80%; background: radial-gradient(#387989, #1b6da6);
  background-repeat: no-repeat;color:#ebff36;border-radius: 12px;border: none;-webkit-box-shadow: 3px 3px 18px -5px rgba(0,0,0,0.75);
-moz-box-shadow: 3px 3px 18px -5px rgba(0,0,0,0.75);
box-shadow: 3px 3px 18px -5px rgba(0,0,0,0.75);margin: 3px;padding:5px">
                </form></center>
                </div>
                    </ion-content>
    </ion-view>

<?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 id="search.html" type="text/ng-template">
    <ion-view view-title="Search">
        <ion-content>
            <h1>Search</h1>
        </ion-content>
    </ion-view>
<?php echo '</script'; ?>
>

    <?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
