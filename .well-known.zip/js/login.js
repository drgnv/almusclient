document.getElementById('login').onclick = function() {
    document.getElementById('password').innerHtml = "";
    document.getElementById('username').innerHtml = "";
}